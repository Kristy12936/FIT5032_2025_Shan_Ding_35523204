<!-- src/views/NotFound.vue -->
<template>
  <div class="container text-center mt-5" data-aos="fade-up">
    <h1 class="display-3">404</h1>
    <p class="lead">Oops! Page not found.</p>
    <router-link to="/" class="btn btn-primary">
      <i class="pi pi-home me-2"></i>Back to Home
    </router-link>
  </div>
</template>

<script setup>
</script>

